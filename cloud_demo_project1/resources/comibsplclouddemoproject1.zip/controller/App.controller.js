sap.ui.define(["sap/ui/core/mvc/Controller"],function(o){"use strict";return o.extend("com.ibspl.clouddemoproject1.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map