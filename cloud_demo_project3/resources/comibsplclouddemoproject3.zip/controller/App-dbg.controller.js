sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.ibspl.clouddemoproject3.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  